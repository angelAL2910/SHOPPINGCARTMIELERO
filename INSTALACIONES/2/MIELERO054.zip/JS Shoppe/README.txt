README
For easy installation:

1) Extract all files in the same directory/folder.
2) Open the shoppingcart.js file to view more information about this software.
3) Open Shoppe Generator.html

Tip: Open shoppingcart.js from a text editor to view further information about JS Shoppe v1.1.