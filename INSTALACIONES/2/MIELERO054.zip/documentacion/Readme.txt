Read this file, it contains important information about this program. If you do not want read now this file is in the path 
documentacion/Reame.txt or documentacion/Reame.rtf of directory where you install this aplication.

1-What is this program??.

This program allows you to make skeletons of virtual Shops that any can modified with only a few web programation knowleadge.
The prgram is a folk version of JS Shoppe v1.1 by Elaine Aquino available i n the folder JS Shoppe. For more information 
of this program please, visit AQ Online Networks ( www.aqonlinenetworks.com).

2-What requeriments is necesary for execute this program?

For use this program is require the Java Run-Time Environ 1.4 or highlet avalaible in http://java.sun.com and for viewing to 
the shops make some web navigators and wap navigators.

3-How install/unistall this program?
This program present two formats which are: 
  - How a msi file of Microsoft Windows that installs the application, makes a shortcut and allows unistall the application 
  how a normal aplication of windows
  - How a zip file which there is to extract in a directory and to execute the file "Mielero.jar" for running the 
  application. The icon file "cart.ico" is included to create a shortcut of the aplication if you want to do this.

Both packs have got the same files, they include the source code and documents.

 



  